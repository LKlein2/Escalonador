﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Escalonador
{
    public class Airplane
    {
        public int Index { get; set; }

        public Airplane(int index)
        {
            this.Index = index;
        }
    }
}
